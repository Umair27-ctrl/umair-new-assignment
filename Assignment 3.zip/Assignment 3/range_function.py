def sum_of_evens(n):
    return sum(i for i in range(0, n + 1, 2))

print(sum_of_evens(10)) 